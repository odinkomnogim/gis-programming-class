# -*- coding: utf-8 -*-
def classFactory(iface):
    from .countfeatures import CountFeatures
    return CountFeatures(iface)
